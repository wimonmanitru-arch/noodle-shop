// Google Apps Script: วางโค้ดนี้ใน Extensions > Apps Script ของ Google Sheets
function doPost(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName("Orders") || ss.insertSheet("Orders");
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["วันเวลาสั่งซื้อ","เลขที่คำสั่งซื้อ","ชื่อลูกค้า","เบอร์โทร","ที่อยู่","SKU / สินค้า","จำนวน","ราคาต่อชิ้น","ยอดรวมรายการ","ยอดรวมคำสั่งซื้อ","หมายเหตุ","สถานะ"]);
  }
  const order = JSON.parse(e.postData.contents);
  order.items.forEach(item => sheet.appendRow([
    new Date(order.createdAt), order.orderId, order.customerName, order.phone,
    order.address, item.sku + " / " + item.product, item.quantity, item.unitPrice,
    item.subtotal, order.total, order.note || "", order.status
  ]));
  return ContentService.createTextOutput(JSON.stringify({ok:true,orderId:order.orderId}))
    .setMimeType(ContentService.MimeType.JSON);
}
